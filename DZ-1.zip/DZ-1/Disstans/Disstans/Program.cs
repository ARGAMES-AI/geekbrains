﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Disstans
{
    class Program
    {
        static void Main(string[] args)
        {

            // а) Написать программу, которая подсчитывает расстояние между точками 
            // с координатами x1, y1 и x2,y2 по формуле r=Math.Sqrt(Math.Pow(x2-x1,2)+Math.Pow(y2-y1,2).
            // б) *Выполните предыдущее задание, оформив вычисления расстояния между точками в виде метода;

            // Шаров В.В.

            Console.ForegroundColor = ConsoleColor.Green;

            Console.SetCursorPosition(0, 1);

            Console.Write("Введите x1:");

              double x1 = double.Parse(Console.ReadLine());
            //x1 = Convert.ToDouble(Console.ReadLine());
            Console.Write("А теперь y1:");

              double y1 = double.Parse(Console.ReadLine());

            Console.Write("Укажите x2:");

              double x2 = double.Parse(Console.ReadLine());

            Console.Write("И y2:");

              double y2 = double.Parse(Console.ReadLine());

            // пункт ДЗ - 3а

              double lens1 = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y2, 2));

            // пункт ДЗ - 3б

            double lens2 = Distans(x1, y1, x2, y2);

            Console.WriteLine("Расстояние по п.3а-ДЗ:" + lens1);

            Console.WriteLine("Растояние по пукту 3б-ДЗ, через метод:" + lens2);

            Console.ReadLine();

        }

        static double Distans(double x1, double y1, double x2, double y2)
        {
            double lens = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y2, 2));

            return lens;
        }
    }
}
