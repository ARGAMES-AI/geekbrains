﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Anketus
{
    class Program
    {
        static void Main(string[] args)
        {

            // 1. Написать программу «Анкета». Последовательно задаются вопросы (имя, фамилия, возраст, рост, вес).
            //    В результате вся информация выводится в одну строчку.
            //    а) используя склеивание;
            //    б) используя форматированный вывод;
            //    в) *используя вывод со знаком $.

            //    Шаров В.В.

2.Ввести вес и рост человека. Рассчитать и вывести индекс массы тела(ИМТ) по формуле I = m / (h * h); где m — масса тела в килограммах, h — рост в метрах

            Console.Write("Ваше имя:");

                string name = Console.ReadLine();

            Console.Write("Укажите фамилию:");

                string familia = Console.ReadLine();

            Console.Write("Ваш возраст:");

             string age = Console.ReadLine();

           
            Console.Write("Подскажите Ваш рост:");

             double height = double.Parse(Console.ReadLine());

            Console.Write("Укажите вес:");

            double massa = double.Parse(Console.ReadLine());

            Console.WriteLine("Ваши имя:{0} Фамилия:{1} Возраст: {2}  Рост:{4} Вес:{3}", name, familia, age, height, massa);
            
            Console.WriteLine("Ваши имя:" + name + " Фамилия:" + familia + " Возраст: " + age + " Год рождения:" + " Рост:" + height + " Вес:" + massa);

            Console.WriteLine($"Ваши имя:{name} Фамилия:{familia} Возраст: {age} Рост:{height} Вес:{massa}");

         // расчет индекса массы тела
            
                double imt = massa / (height * height);

            Console.WriteLine("Ваш индекс массы тела:" + imt);

            Console.ReadLine();

        }
    }
}
