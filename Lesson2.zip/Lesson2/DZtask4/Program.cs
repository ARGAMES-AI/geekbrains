﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZtask4
{
    class Program
    {
        static void Main(string[] args)
        {

            // Урок 2. ДЗ: 4. Реализовать метод проверки логина и пароля. На вход подается логин и пароль.
            //                На выходе истина, если прошел авторизацию, и ложь, если не прошел (Логин: root, Password: GeekBrains).
            //                Используя метод проверки логина и пароля, написать программу: пользователь вводит логин и пароль,
            //                программа пропускает его дальше или не пропускает.
            //                С помощью цикла do while ограничить ввод пароля тремя попытками.

            // Шаров В.В.


            string login = "root";
            string password = "GeekBrains";

            int shans = 0;

            do
            {
                Console.WriteLine("Введите логин: ");
                string checkLogin = Console.ReadLine();

                Console.WriteLine("Введите пароль: ");
                string checkPassword = Console.ReadLine();

                if (login == checkLogin && password == checkPassword)
                {

                    Console.WriteLine("Добро пожаловать");                    
                    break;
                }
                Console.WriteLine("Неверно введен логин или пароль, попробуйте еще раз!");
                // Console.ReadLine();
                shans = shans + 1;
            } while (shans < 3);

            Console.WriteLine("Вы превысили колличество попыток ввода. Попробуйте, после оздоровительного сна!");

            Console.ReadKey();

        }
    }
}
