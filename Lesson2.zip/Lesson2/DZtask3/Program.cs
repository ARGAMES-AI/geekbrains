﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZtask3
{
    class Program
    {
        static void Main(string[] args)
        {

            // Урок 2. ДЗ: 3. С клавиатуры вводятся числа, пока не будет введен 0.
            //                Подсчитать сумму всех нечетных положительных чисел.

            // Шаров В.В.


            int summa = 0;
            int number = 0;

            do
            {
                Console.WriteLine("Вводите числа. Для подсчета суммы нечетных и положительных чисел, введите цифру 0: ");

                number = int.Parse(Console.ReadLine());

                if (number > 0 && number % 2 == 1)

                    summa = summa + number;

            } while (number != 0);

            Console.WriteLine("Сумма: " + summa);


            Console.ReadKey();

        }
    }
}
