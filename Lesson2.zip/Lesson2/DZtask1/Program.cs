﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZTask1
{
    class Program
    {
        static void Main(string[] args)
        {

            // Урок 2. ДЗ: 1. Написать метод, возвращающий минимальное из трех чисел.

            // Шаров В.В.

            Console.ForegroundColor = ConsoleColor.DarkBlue; // как в добром, старом Бейсике?! )))
                                                             // Помню даже запах моего ZX Spectrum...

            double a, b, c;

            Console.Write("Введите первое число: ");

                a = Convert.ToDouble(Console.ReadLine());


            Console.Write("Введите второе число: ");

                b = Convert.ToDouble(Console.ReadLine());


            Console.Write("Введите третье число: ");

                c = Convert.ToDouble(Console.ReadLine());


            Console.WriteLine("Минимальное число, введеное Вами: " + Minimum(a, b, c).ToString());

            Console.ReadKey();

        }

        static double Minimum(double a, double b, double c)
        {
            double min = 0;

            if (a <= b && a <= c) { min = a; }
            else
            {
                if (b <= a && b <= c) { min = b; }
                else
                {
                    if (c <= b && c <= a) { min = c; }
                }
            }

            return min;
        }

    }
}
