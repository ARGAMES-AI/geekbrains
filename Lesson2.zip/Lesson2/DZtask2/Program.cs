﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZtask2
{
    class Program
    {
        static void Main(string[] args)
        {

            // Урок 2. ДЗ: 2. Написать метод подсчета количества цифр числа.

            // Шаров В.В.

            Console.SetCursorPosition(0, 4);

            Console.Write("Введите Ваше число : ");

                int number = int.Parse(Console.ReadLine());

                int i = 0;

            while (number > 0)
            {
                i++;

                number = number / 10;
            }

            Console.WriteLine("Количество цифр введенного числа : {0}", i);
                   

            Console.ReadKey();

        }
    }
}
